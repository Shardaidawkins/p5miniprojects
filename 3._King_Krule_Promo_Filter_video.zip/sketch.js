
let firstLine = "MANALIVE !";
let secondLine = "King Krule";
let mainVideo;
let font;
let mimg;
let playing = false;
let button;

function preload() {
    font = loadFont('FilmNoir.ttf');
  
    mimg = loadImage('Manalive.png');
} 

function setup() {

  button = createButton('PLAY!');
  
  button.mousePressed(PlaypauseVid);
  
  mainVideo = createVideo('Kingkrule.mp4', () => {
    mainVideo.loop();
    mainVideo.hide();
    mainVideo.loadPixels();
    createCanvas(mainVideo.width,mainVideo.height);
    });
  

  }

function draw() {
 
    background(0);
    mainfilter(mainVideo);
    image(mimg, 0, 0);
   
}

function mainfilter(theCanvas) {
    fill(255);
    textSize(100);
    textFont(font);
    textAlign(CENTER);
    text(firstLine,width/2,height/7 + height/4);
    text(secondLine, width/2, height/2 + height/4);
    
    let img = get(0, 0, width, height);
    image(theCanvas,0,0);
    imagePosition(img, theCanvas);
	img.resize(width, height);
    image(img, 0, 0);
}

function imagePosition(imgPos, img) {
    img.loadPixels();
    imgPos.loadPixels();

    for(let i = 0; i < imgPos.pixels.length; i += 4) {
        if(imgPos.pixels[i] != 0) {
            for(let t = i; t < i + 4; t++) {
                imgPos.pixels[t] = img.pixels[t];
            }
        } 
    }
  
    imgPos.updatePixels();
}

function PlaypauseVid() {
  if (playing) {
    mainVideo.pause();
    
    button.html('PLAY!');
    
  } else {
    mainVideo.loop();
    button.html('PAUSE!');
  }
  playing = !playing;
}
