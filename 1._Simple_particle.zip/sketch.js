let bees = []; // Array for the bees 
let clouds = [{}, {}, {},]; // Array for the clouds
let beesound;
 
function preload() {
 beesound = loadSound('Beehivesound.mp3');
}

function setup() {
  createCanvas(600, 500);
  fill(240); //
  noStroke();
  beesound.loop();
 
}

function draw() {
  //Background settings to make sky & floor
  background('#8EE5EE');
  noStroke();
  fill('#78AB46'); 
  rect(0,400,600,100);
 
  
  // Beekeeper
  // Head
  fill('white');
  ellipse(300,300,60,60);
  // Body
  fill('#f5e1a9');
  rect(280,330,40,70);
  // Legs
  rect(280,350,10,80);
  rect(310,350,10,80);
  // Arms
  strokeWeight(4);
  stroke('#f5e1a9');
  line(330,335,320,350);
  line(320,365,350,360);
  strokeWeight(1);
  // Shoes
  noStroke();
  fill('#8b0000');
  rect(310,420,11,11);
  rect(280,420,11,11);
  // Hands
  rect(350,355,11,11);
  rect(330,330,11,11);
  // Helmet
  stroke("beige");
  fill('rgba(128,128,128, 0.25)');
  rect(270,270,60,60);
  triangle(255, 270, 340, 270, 300, 240);
  // Face
  ellipse(290,292,10,10);
  ellipse(310,292,10,10);
  ellipse(300,310,30,20);
  
  
  // Tree and nest
  noStroke();
  fill("#654321");
  rect(70,130,20,270);
  rect(70,190,60,10);
  rect(120,200,10,20);
  fill("#FFD300");
  ellipse(125,240,50,60);
  fill("black");
  ellipse(125,250,15,15);
  
  fill("green");
  ellipse(50,130,80,80);
  ellipse(90,130,80,80);
  ellipse(120,130,80,80);
  ellipse(90,90,80,80);
  
  
  //Bee box
  fill("#ccb59b");
  rect(440,320,90,90);
  fill("#654321");
  rect(430,310,110,10);
  ellipse(485,340,20,20);
  rect(458,360,55,5);
  ellipse(485,390,20,20);
  rect(460,410,4,15);
  rect(510,410,4,15);
  

  // For loop for the clouds
  
  for (i = 0; i < clouds.length ; i++) {
    noStroke();
    fill("white");
    ellipse(100+200*i,60,40,40)
    ellipse(100+200*i,40,40,40)
    ellipse(80+200*i,40,40,40)
    ellipse(60+200*i,40,40,40)
    ellipse(60+200*i,60,40,40)
    ellipse(80+200*i,60,40,40)
    }
  
  
  // Colour for the bees
  stroke("black");
  fill('yellow');
  
  
// Code to generate particle moments to mimick the movement of bees
  
  let f = frameCount / 50; // Setting the speed of the bees movement

  // For loop to create a random amount of bees in each frame
  for (var i = 0; i < random(5); i++) {
    bees.push(new bee()); // Adding the bee objects 
  }

  // For loop to get the bees to be displayed
  for (let hive of bees) {
    hive.update(f); // update bee position
    hive.display(); // draw bee
  }
}


function bee() {
  // Setting the starting positions for the bees in which i made it the bee hive opening. As well as setting the angle and size of them. 
  this.positionX = 125;
  this.positionY = 280;
  this.startingangle = random(0, 4 * PI);
  this.beesize = random(3, 6);

  
  // Written so the bees are spread out.
  this.radius = sqrt(random(pow(width / 2, 2.4)));

  this.update = function(time) {
    let s = 0.8; //speed
    let angle = s * time + this.startingangle;
    this.positionX = width / 2 + this.radius * cos(angle);

    // Written so bees fall differently on the y axis. 
    this.positionY += pow(this.beesize, 0.8);

    // Making sure the bees are stop if they go past the screen.
    if (this.positionY > height) {
      let index = bees.indexOf(this);
      bees.splice(index, 3);
    }
  };

  this.display = function() {
    ellipse(this.positionX, this.positionY, this.beesize);
  };
  

 function mousePressed() {
  //Beesounds
  if (mouseX, mouseY) {
    beesound.play();
  }

  
 
  
}
}