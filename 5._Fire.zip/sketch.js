var dots = [];
var sparks = [];
let a = 100;

let angle = 0;

let firesound;

//cloud variables
var cloudX = [];
var cloudY = [];
var cloudSpeed = [];


function preload() {
  
  
   firesound = loadSound('fire.mp3');
}

function setup() {
  createCanvas(700, 600);
  
   firesound.loop();
  
	colorMode(HSB, 360, 100, 100, 100);

	for (let x = 0; x < 10; x++) {
		dots[x] = new Dot();
		sparks[0] = new Spark();
	}
  
  
   //Initialise cloud variables
  for(var i = 0; i < 5; i ++){
    cloudX[i] = random(width);
    cloudY[i] = 75+i*50;
  }
  
}




function draw() {
  background("#87CEEB");
  
  fill("lightgrey");
  rect(5,320,80,262);
  
  rect(85,272,110,310);
  rect(195,320,80,262);
  triangle(5, 272, 280, 272, 140, 90);
  
  
  fill("#8b0000");
  rect(400,460,220,100);
  rect(350,430,90,130);
  fill("Black")
  ellipse(430,550,80,80);
  ellipse(570,550,80,80);
  fill("grey");
  ellipse(430,550,40,40);
  ellipse(570,550,40,40);
  fill("#87CEEB");
  rect(370,440,50,50);
  fill("orange");
  rect(380,410,20,20);
  
  
  
//fire 
  
  noStroke();
  dots.push(new Dot());
	if (frameCount % 5 == 0) {
		sparks.push(new Spark());
	}

	for (let x = 0; x < dots.length; x++) {
		if (dots[x].size <= 0) {
			dots.splice(x, 1);
		}
	}

	for (let x = 0; x < sparks.lenght; x++) {
		if (sparks[x].y <= 0) {
			sparks.splice(x, 1);
		}
	}

	for (let x = 0; x < dots.length; x++) {
		dots[x].display();
		dots[x].move();
	}

	for (let x = 0; x < sparks.length; x++) {
		sparks[x].display();
		sparks[x].move();
	}
  
  angleMode(DEGREES);
  a = 0.04
 
  push();
  translate(random(-100,100),random(-100,100));
  fill(random(0,50),random(0,100),100) 
  circle(150,150,5);
  circle(190,190,5);
  pop();
    
 
  push();
  stroke(50,random(0,100),100) 
  translate(160,160);
  rotate(angle);
  ellipse(0,0,random(50,100),1);
  angle = angle+1000
pop(); 
  
  
  
    //clouds
  fill(255);
  
  //drawing clouds
  for(var i = 0; i < 5; i ++){
    clouds(cloudX[i], cloudY[i]);
    cloudX[i] = cloudX[i] + 0.5;
		//clouds have jitter movement in y-axis
    cloudY[i] = cloudY[i] + random(-0.5, 0.5);
  
  //when clouds reach beyond edge of screen, clouds reset to original side
    if (cloudX[i] > width+50) {
      cloudX[i] = -50;
    }
  }
  
  
  
function clouds(x, y){
  ellipse(x, y, 30);
  ellipse(x+10, y, 25);
  ellipse(x+10, y-10, 30);
  ellipse(x+20, y, 25);
  ellipse(x+30, y, 25);
  
}}

class Dot {

	constructor() {
		this.start();
	}

	start() {
		this.x = random(width / 2 - 400, width / 2 + 120);
		this.y = height;
		this.size = 100;
		this.velY = random(3, 7);
		this.h = random(0, 50);
		this.a = 50;
	}

	display() {
		fill(this.h, 100, 100, this.a);
		ellipse(this.x, this.y, this.size, this.size);
	}

	move() {
		this.y -= this.velY;
		this.x += cos(this.y) * 2;
		this.size -= 2;
		this.a -= 1.5;
	}
}

class Spark {

	constructor() {
		this.start();
	}

	start() {
		this.x = random(width / 2 - 400, width / 2 + 25);
		this.y = height + 50;
		this.size = 2;
		this.velY = random(5, 10);
	}

	display() {
		fill(0, 100, 100, 100, 10);
		ellipse(this.x, this.y, this.size, this.size);
	}

	move() {
		this.y -= this.velY;
		this.x += cos(this.y) * 1;
	}
}

