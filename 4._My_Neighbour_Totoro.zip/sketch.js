let drop = new Array(100);
var x;
var y;
var speed;
let rainsound;

let img;

function preload() {
  img = loadImage('indarain.png');
  
   rainsound = loadSound('Rain.mp3');
}

function setup(){
  createCanvas(620,580);
  
   for(var i=0;i<drop.length;i++){
    drop[i]=new Drop();
   }
  
  rainsound.loop();
   
}

function draw(){
  
 
  //Day/night cycle background colours
  var cycle = map(mouseY, 0, height, 0, 1);
  var night = color(27,30,35);
  var day = color(0,0,100);
  var gradient = lerpColor(day, night, cycle);
  
	background(gradient);
  
  
  for(var i=0;i<drop.length;i++){
    drop[i].rain();
    
    
  //lighttimerain 
  var rainSunY = map(mouseY, 0, height, 80, height+75);
  noStroke();
  fill("lightgrey");
  ellipse(580, rainSunY, 100);
    
  //nightimetrain
   var SunY = map(mouseY, 0, height, height+75, 60);
  fill('grey');
  ellipse(580, SunY, 100);
  
  //green background
  fill('#1F3D0C');
  rect(0,480,800,100);
  
  

    
  }
  
   image(img,100, 360);
  
   //bus-stop
   fill("grey")
   rect(20,520,50,20);
   rect(38,300,12,220);
   rect(25,360,40,50);
   fill("#92B7FE");
   ellipse(45,280,60,60);
  
  
  
  
  if(mouseY >= 200){
  
    fill('grey');
   ellipse(400,470,180,220);
  
    //ears
   ellipse(360,350,30,60);
  ellipse(440,350,30,60);
    
    //arms
    
    ellipse(320,480,40,110);
    ellipse(480,480,40,110);
    
    //leaf
    
    fill("green");
    ellipse(400,350,50,20);
    ellipse(400,330,2,20);
    
    
   fill(225,198,153);
   ellipse(400,510,130,120);
   ellipse(400,510,130,120);
    
 
    
  fill('white');
    
   ellipse(360,400,30,30);
   ellipse(440,400,30,30);
  
  fill('black');
   ellipse(440,400,10,10);
  ellipse(360,400,10,10);
    
  ellipse(400,405,30,10);
  stroke('#222222');
  line(350, 440, 280, 410);
  line(350, 450, 280, 450);
  line(350, 460, 280, 490);
 
    
  line(510, 420, 440, 440);
  line(510, 450, 440, 450);
  line(510, 470, 440, 460);
    
  
    
  }
  
 
}



class Drop{
constructor() {
		this.x=random(0,width);
		this.y=random(-100,0);
		this.speed=random(1,10);
	}
  rain(){
    stroke(255,255,255);
    
    line(this.x,this.y,this.x,this.y+7);
    this.y=this.y+this.speed;
    if(this.y > height){
      this.y = random(-100,0);
    }
  }
}


