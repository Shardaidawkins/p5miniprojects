let Aphex;
 
function preload() {
 Aphex = loadSound('AphexTwin.mp3');
  
}

function setup() {
  createCanvas(700, 1000, WEBGL);
  Aphex.loop();
}

function draw() {
  
  background("#89cff0");
  
  noStroke()
  
  rotate(PI/4, [1,1,0]);
  ambientLight(150);
  directionalLight(137, 207, 240, 0.5, 0.25, 0);
  directionalLight(233, 50, 50, -0.5, 0.5, 0);
  
  
  translate(-width/2.5, -height/1);
  specularMaterial(100);
  pointLight(100, 200, 100, mouseX - mouseY/2, mouseY - mouseX/2, 50);
  
  for(var i = 0; i < width; i += 80){
    for(var t = 0; t < height; t += 80){
      push()
      
      translate(i,t)
      rotateZ(cos(i * t / 1000 + frameCount / 1000) /10 + mouseY / 400)
      rotateX( mouseY / 400)
      cylinder(0.1 + sin (i / 50 + frameCount / 20 + mouseY / 100 ) * 50 + cos (t / 50 + frameCount / 10 ) * 30, 10)
      
      pop()
    
    }	
  } 
}